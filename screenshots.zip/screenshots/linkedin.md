Slop Zürich 🇨🇭 (work in progress)

I couldn't resist applying mrdoob's Slop New York to Zürich: three.js, WebGPU and TSL on Swiss open data.

🏛️ swissBUILDINGS3D: 15,281 buildings from 811 3D Tiles, exact ECEF→LV95, calibrated on surveyed roof tops
⛰️ swissALTI3D: the real relief, Limmat to ETH
🌉 swissSURFACE3D: bridge decks (Hardbrücke 12 m above the tracks)
🏔️ swissALTIRegio: horizon to the Alps, with Earth curvature
🌳 OSM, 16,000 city trees, 40 VBZ trams

Built with Claude Opus 5.5 (Claude Code), from data pipeline to terrain engine.

▶ zurich.pocketswitzerland.ch
💻 github.com/colorfield/slop-zurich

© swisstopo · © OpenStreetMap · Stadt Zürich OGD
#threejs #WebGPU #swisstopo #OpenData #GIS
