Slop Zürich 🇨🇭 a work in progress

I couldn't resist: mrdoob's Slop New York, but in Zürich. Cycle, walk, drive or fly through the city in your browser 🚲

🏛️ 15,281 real buildings with their roofs
⛰️ the real relief, from the Limmat to the ETH
🌉 bridges at their surveyed height
🏔️ the lake and the Alps on the horizon
🌳 16,000 city trees, 🚋 40 VBZ trams

three.js + WebGPU on swisstopo open data, built with Claude Opus 5.5 (Claude Code).

🔗 zurich.pocketswitzerland.ch (link in bio, best on desktop)

© swisstopo · © OpenStreetMap · Stadt Zürich OGD
#zurich #switzerland #swisstopo #threejs #webgpu #creativecoding #opendata #claudeai
